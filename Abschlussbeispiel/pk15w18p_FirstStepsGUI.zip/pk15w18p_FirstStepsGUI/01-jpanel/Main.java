public class Main {
    public static void main(String[] args) {
        // Diesen Code bitte *nicht* übernehmen!
        // vgl. https://docs.oracle.com/javase/tutorial/uiswing/concurrency/initial.html
        Window w = new Window();
        w.setVisible(true);
    }
}
